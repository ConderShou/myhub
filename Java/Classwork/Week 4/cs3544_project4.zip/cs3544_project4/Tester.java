
public class Tester {

	public static void main(String[] args) {
		Game blackjack = new Game();
		
		blackjack.play();

	}

}
